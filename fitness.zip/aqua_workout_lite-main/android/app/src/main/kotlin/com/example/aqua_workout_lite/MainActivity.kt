package com.example.aqua_workout_lite

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
